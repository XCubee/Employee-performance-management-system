# Employee Performance Management System

## Requirements

- Python 3.10 or newer
- A Supabase project with the tables and columns expected by the application

## Setup

Extract the ZIP, open a terminal in the extracted `epms_html` folder, and create a virtual environment.

On Windows:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item config.example.ini config.ini
```

On macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp config.example.ini config.ini
```

Edit `config.ini` and replace the example values with your Supabase project URL and service-role key. Keep this file private and do not commit or share it.

## Run

With the virtual environment active and `config.ini` configured, run:

```sh
python app.py
```

Open <http://127.0.0.1:5000> in a browser. The first account setup page creates the initial HR account in the configured Supabase database.

The ZIP does not include Supabase credentials or database schema. Configure the project and create the tables expected by the application before using database-backed features.
